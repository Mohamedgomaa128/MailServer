package eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment;

public enum Importance {
	veryImportant,
	Important,
	medium,
	low	
}
