package eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses;

public interface Iterator {
	public boolean hasNext();
	public Object next();
}
