package eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses;

public class nulls {

	/*public static User loadUser(String emailAddress) {
	//loadSystemUsers
	//then iterate and get it by comparisons
}

public static ArrayList<User> loadSystemUsers() {
	
}*/
	
	
	/*
	 public static void saveUser(User u) {
		File usersFolder = new File("users\\" + u.getEmailAddress());
		
		try {
			usersFolder.mkdirs();
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		
		File userFile = new File("users\\" + u.getEmailAddress() + "\\userFile.txt");

		try {
			usersFolder.mkdirs();
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		
		
		
		
	}
	 */
	
	/*public void addContactEmail(String email) {
	ArrayList<User> arr = reciever.getOriginalUser();
	
	User rec = null;
	
	for (int i = 0; i < arr.size(); i++)
		if (arr.get(i).getEmailAddress().equals(email))
			rec = arr.get(i);

	builder.setReciever(rec);
	
	
}*/

	
	/*public static void autoDeleteTrash() {
	// called at the beginning of the program
	try {
		Path file = Paths.get("");
		FileTime creationTime = (FileTime) Files.getAttribute((Path)(.getPath()), "creationTime");
	}
	catch() {
		
	}
	
	
}*/
		
}
