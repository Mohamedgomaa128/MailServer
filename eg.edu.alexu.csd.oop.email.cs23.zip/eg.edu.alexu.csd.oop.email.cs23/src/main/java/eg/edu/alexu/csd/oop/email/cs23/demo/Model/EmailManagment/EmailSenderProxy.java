package eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment;

import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.ArrayListIterator;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.PageAdapter;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.Paging;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.WithFiles;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.Contact;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.Folder;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.User;

import java.io.File;
import java.util.ArrayList;

public class EmailSenderProxy implements EmailSender{
	private EmailBuilder builder;
	public EmailSenderProxy() {
		builder = new EmailBuilder();
	}
	public EmailSenderProxy(Email e) {
		builder = new EmailBuilder(e);
	}



	@Override
	public void addSubject(String subject) {
		builder.setSubject(subject);
	}

	
	@Override
	public void addBody(String body) {
		builder.setBody(body);
	}
	public void SetDate(String Date){
		builder.setDate(Date);
	}

	
	@Override
	public void addAttachement(File attachement) {
		builder.addAttachement(attachement);
	}
	
	@Override
	public void send(String sender, ArrayList<String>reciever, boolean send) {
		//System.out.println(reciever.size());
		for(int i=0;i<reciever.size();i++) {
			builder.setSender(sender);
			builder.addReciever(reciever.get(i));
			//System.out.println(sender);
			//System.out.println(reciever.get(i));

			Email e = builder.getEmail();
			//System.out.println(e);
			WithFiles.addIdToEmail(e);
			User s = WithFiles.readUser(sender);
			User r = WithFiles.readUser(reciever.get(i));
			//may update to add more conditions
			if (send) {
				if(e==null){
					Folder senderDraft = s.getDefaultFolders().get(3);
					senderDraft.addToEmailsList(e);
					WithFiles.writeUser(s);
					}
				else {
				Folder recieverInbox = r.getDefaultFolders().get(0);
				//recieverInbox.setPath("users\\" + reciever.getEmailAddress() + "\\defaultInbox\\");
				recieverInbox.addToEmailsList(e);

				Folder senderSentEmail = s.getDefaultFolders().get(4);
				//senderSentEmail.setPath("users\\" + sender.getEmailAddress() + "\\sentEmails\\");
				senderSentEmail.addToEmailsList(e);
				WithFiles.writeUser(r);
				WithFiles.writeUser(s);
				}
			} else {
				Folder senderDraft = s.getDefaultFolders().get(3);
				senderDraft.addToEmailsList(e);
				WithFiles.writeUser(s);
			}
		}
		//not essential as you will need to write this user after each update

	}
	
	
	public static void main(String[] args) {

		User u1 = new User();
		u1.setEmailAddress("mostaf@...com");
		User u2 = new User();
		u2.setEmailAddress("killer@...com");
		WithFiles.initUser(u1);
		WithFiles.initUser(u2);

		Contact c1 = new Contact();


		u1.addToContacts(c1);

		
		EmailSenderProxy ex = new EmailSenderProxy();
		
		ex.addBody("here we are");
		ex.addSubject("test");

		System.out.println(ex.builder.getEmail());
		//File f = new File("E:\\Quran\\الشيخ عبدالرحمن الزواوي\\12-يوسف\\سورة يوسف.mp4");
		//File f2 = new File("E:\\fall 2021\\first term\\numericals\\Numerical-Session 3 N.pdf");
		//ex.addAttachement(f2);
		//ex.addAttachement(f);
		
		/*ex.send(u1, u2, true);
		ex.send(u1, u2, true);
		ex.send(u1, u2, true);
		
		for (int i = 0; i < 3; i++)
			u2.getDefaultFolders().get(0).getEmailsList().get(i).print();
		
		u2.getDefaultFolders().get(0).getEmailsList().get(0).print();
		WithFiles.writeUser(u1);
		WithFiles.writeUser(u2);

		System.out.println(u1.getDefaultFolders().get(4).getEmailsList());
		u1.getDefaultFolders().get(4).getEmailsList().get(0).print();
		System.out.println(u2.getDefaultFolders().get(0).getEmailsList());
		
		Paging p = new PageAdapter(u1);
		
		ArrayListIterator it = p.getPage(3, 1, 4);
		System.out.println();
		
		while(it.hasNext())
			((Email) it.next()).print();
		System.out.println(u1.getDefaultFolders().get(0).getPath());*/
	}

	
	
	

}
