package eg.edu.alexu.csd.oop.email.cs23.demo.Controller;

import com.fasterxml.jackson.annotation.JsonProperty;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment.Email;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.Contact;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.User;
import eg.edu.alexu.csd.oop.email.cs23.demo.Services.Services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.ArrayList;

//@CrossOrigin(origins = "http://localhost:8081")
@RequestMapping("api")
@RestController
public class Controller {

    private Services services;
    @Autowired
    public Controller(Services services) {
        this.services = services;
    }
    @GetMapping("/login")
    public String Login(@RequestParam(value = "Emailaddress")String Emailaddress,
                      @RequestParam(value = "password")String password)
    { System.out.println("Name");
        String access=this.services.login(Emailaddress,password);
        this.services.getUser();
        return access;
    }
    @GetMapping("/getUser")
    public String getUser(){
        return this.services.getUser();
    }
    @GetMapping("/signUp")
    public String SignUp(@RequestParam(value = "emailaddress")String emailaddress,
                        @RequestParam(value = "password")String password,
                        @RequestParam(value = "userName")String userName)
    { return this.services.SignUp(emailaddress,password,userName);}
    @GetMapping("/addContact")
    public String addContact(@RequestBody Contact contact)
    {
        return this.services.addContact(contact);
    }
    @GetMapping("/editContact")
    public String editContact(@RequestParam(value = "contact")Contact contact,
                              @RequestParam(value = "oldName")String oldName)
    {
        return this.services.editContact(contact,oldName);
    }
    @GetMapping("/removeContact")
    public String removeContact(@RequestParam(value = "Name")String Name)
    {
        return this.services.removeContact(Name);
    }
    @GetMapping("/SearchContact")
    public Contact SearchContact(@RequestParam(value = "Sort")String Name)
    {
        return this.services.SearchContact(Name);
    }
    @GetMapping("/SetEmailsToShow")
    public ArrayList<Email> SetEmailsToShow(@RequestParam(value = "FolderIndex")int FolderIndex)
    {
        return this.services.SetEmailsToShow(FolderIndex);
    }
    @GetMapping("/getPage")
    public ArrayList<Email> getPage(@RequestParam(value = "PageNumber")int PageNumber)
    {
        return this.services.getEmailsPage(PageNumber);
    }
    @GetMapping("/GetContactPage")
    public ArrayList<Contact> GetContactPage(@RequestParam(value = "PageNumber")int PageNumber)
    {
        return this.services.getContactsPage(PageNumber);
    }
    @GetMapping(value = "/FilterAndSort")
    public ArrayList<Email> FilterAndSort(@RequestBody ArrayList<ArrayList<String>> Filter,
                                          @RequestParam(value = "sort")String  sort){
        return this.services.FilterAndSorts(Filter,sort);
    }
    @GetMapping(value = "/EmailsNumberOfPages")
    public int EmailsNumberOfpages(){
        return this.services.getEmailsNumberOfPages();
    }
    @GetMapping(value = "/ContactsNumberOfPages")
    public int ContactsNumberOfpages(){
        return this.services.getContactsNumberOfPages();
    }
    @GetMapping(value = "/ComposeMail")
    public String sendMail(@RequestBody Email e, @RequestParam (value = "send")boolean send){
        return this.services.Compose(e,send);
    }


    @GetMapping("/keepMe")
    public void keepMe(){
        services.keepMeLogIn();
    }

    @GetMapping("/logOut")
    public void logOut(){
        services.logOut();
    }

    @GetMapping("/bulkDelete")
    public void bulkDelete(@RequestBody ArrayList<Integer> eListIds, @RequestParam (value = "indexOfDefaultFolder")int indexOfDefaultFolder){
        services.bulkDelete(eListIds, indexOfDefaultFolder);
    }

    @GetMapping("/bulkMove")
    public void bulkMove(@RequestBody ArrayList<Integer> eListIds, @RequestParam (value = "indexOfDefaultFolder")int indexOfDefaultFolder, @RequestParam (value = "indexOfUserFolder") int indexOfUserFolder){
        services.bulkMove(eListIds, indexOfDefaultFolder, indexOfUserFolder);
    }

    @GetMapping("/bulkRetriveFromTrash")
    public void bulkRetriveFromTrash(@RequestBody ArrayList<Integer> eListIds){
        services.bulkRetriveFromTrash(eListIds);
    }


    @GetMapping("/fromDraftResendEmail")
    public void fromDraftResendEmail(@RequestBody Email newEmail,  @RequestParam (value = "id")int id,  @RequestParam (value = "send")boolean send){
        services.fromDraftResendEmail(newEmail, id, send);
    }

    @GetMapping("/addToPriorityInbox")
    public void addToPriorityInbox( @RequestParam (value = "id")int id){
        services.addToPriorityInbox(id);
    }









}
