package eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserFcade;


import eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment.Email;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment.EmailProxy;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.EmailManagment.EmailSenderProxy;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.PageAdapter;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.PagingSystem;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.HelperClasses.WithFiles;
import eg.edu.alexu.csd.oop.email.cs23.demo.Model.UserManagment.*;

import java.io.File;
import java.util.ArrayList;

public class UserFacade {
	public User u;
	/*public UserFacade(){
		u = WithFiles.getKeepMe();
	}*/
	public UserFacade(){
	}
	public UserFacade(User u) {
		this.u = u;
	}
	
	
	// here we add all the functionalities that user wants to do
	
	
	 /*Contact c = createContact(emailAddress, name);
		
		ContactToUserProxy cx = new ContactToUserProxy(u);
		cx.addContact(c);
		*/
	
	public String composeEmail(Email e, boolean send) {
		if((this.u==null)||(e==null)){return"Failed to send Email";}
		else {
			EmailSenderProxy ex = new EmailSenderProxy();
			ex.addSubject(e.getSubject());
			ex.addBody(e.getDate());

			for (int i = 0; i < e.getAttachements().size(); i++)
				ex.addAttachement(e.getAttachements().get(i));

			ex.send(this.u.getEmailAddress(), e.getRecievers(), send);
			this.u=WithFiles.readUser(this.u.getEmailAddress());
			if(send){return "Email Sent Successfully";}
			else {return "Email Drafted";}
		}
	}
	public String signUp(String emailAddress, String passWord,String username) {
		UserBuilder userBuilder = new UserBuilder();
		
		userBuilder.addEmailAddress(emailAddress);
		userBuilder.addPass(passWord);
		userBuilder.addUserName(username);
		return userBuilder.getUser();
	}
	
	public String logIn(String emailAddress, String passWord) {
		User newUser = WithFiles.readUser(emailAddress);
		if(newUser==null){
			return "This Email Address not Exist";
		}
		else {
			 if (newUser.getPassWord().equals(passWord)){
				u = newUser;
			 return "Successfully Log in";}
			else{
				return ("Wrong password");}
			//here we may need to add a loop and reread password and start retreving email
		}
	}

	public String addContact(Contact c){
		if(this.u!=null){
		ContactToUserProxy ContactProxy=new ContactToUserProxy(this.u);
		String inform=ContactProxy.addContact(c);
		return inform;
		}
		else {return "UserAccount Undefined";}
	}
	public String editContact(Contact c,String oldName){
		if(this.u!=null){
			ContactToUserProxy ContactProxy=new ContactToUserProxy(this.u);
			String inform=ContactProxy.editContact(c,oldName);
			this.u=WithFiles.readUser(u.getEmailAddress());
			return inform;
		}
		else return "UserAccount Undefined";
	}
	public String removeContact(String contactName){
		if (this.u!=null){
			ContactToUserProxy ContactProxy=new ContactToUserProxy(this.u);
			String inform=ContactProxy.removeContact(contactName);
			this.u=WithFiles.readUser(u.getEmailAddress());
			return inform;
		}
		else return "UserAccount Undefined";
	}
	public  ArrayList<Email>SetEmailsToShow(User u,int EmailsInd){
		if(u==null){
			System.out.println("UserUndefined");
			return null;}
		PagingSystem p=new PagingSystem(u,EmailsInd);
		return p.getEmails();
	}
	public ArrayList<Email>FilterAndSorts(User u,int EmailsInd,ArrayList<ArrayList<String>> Filters,String sort){
		if(u==null){
			System.out.println("UserUndefined");
			return null;}
		PagingSystem p=new PagingSystem(u,EmailsInd);
		p.setEmails(p.Filter(Filters));
		p.Sorts(sort);
		return p.getEmails();
	}
	public ArrayList<Email>GetPage(int countOfEmails, int pageNumber, ArrayList<Email>ShowingEmails){
		if(ShowingEmails==null){
			System.out.println("UserUndefined");
			return null;}
		PageAdapter p=new PageAdapter();
		return 	p.getPage(countOfEmails,pageNumber,ShowingEmails);
	}
	public Contact SearchContact(String name){
		if(this.u==null){
			System.out.println("UserUndefined");
			return null;}
		ContactToUserProxy e=new ContactToUserProxy(this.u);
		return e.SearchContact(name);
	}
	public ArrayList<Contact>userContacts(){
		if(u==null){ System.out.println("UserUndefined");return null;};
		return u.getContacts();}
	public ArrayList<Contact>contactsPage(int countofContacs,int pagenumber,ArrayList<Contact>ShowingContacts){
		if(ShowingContacts==null){
			System.out.println("UserUndefined");
			return null;}
		PageAdapter p=new PageAdapter();
		return p.getContactsPage(countofContacs,pagenumber,ShowingContacts);
	}

	public void keepMeLogIn() {
		WithFiles.keepMeLogIn(u);
	}

	public void logOut(){
		WithFiles.keepMeLogOut();
	}

	
	public void bulkMove(ArrayList<Integer> eListIds, int indexOfDefaultFolder, int indexOfUserFolder) {
		EmailProxy epx = new EmailProxy(u);

		for (int i = 0; i < eListIds.size(); i++)
			epx.moveEmail(indexOfDefaultFolder, indexOfUserFolder, eListIds.get(i));

		WithFiles.writeUser(u);
	}

	public void bulkDelete(ArrayList<Integer> eListIds, int indexOfDefaultFolder) {
		EmailProxy epx = new EmailProxy(u);

		for (int i = 0; i < eListIds.size(); i++)
			epx.deleteEmail(indexOfDefaultFolder, eListIds.get(i));

		WithFiles.writeUser(u);
	}

	public void bulkRetriveFromTrash(ArrayList<Integer> eListIds){
		EmailProxy epx = new EmailProxy(u);

		for (int i = 0; i < eListIds.size(); i++)
			epx.retriveFromTrash(eListIds.get(i));

		WithFiles.writeUser(u);
	}

	public void fromDraftResendEmail(Email newEmail, int id, boolean send) {
		EmailProxy epx = new EmailProxy(u);

		epx.fromDraftResendEmail(newEmail, id, send);

		WithFiles.writeUser(u);
	}

	public void addToPriorityInbox(int id){
		EmailProxy epx = new EmailProxy(u);
		epx.addToPriorityInbox(id);

		WithFiles.writeUser(u);
	}



	public static void main(String[] args){
	    User u = WithFiles.readUser("radwan@gmail.com");
		User u2 = WithFiles.readUser("uo@do");

		//Folder f = new Folder();
	    WithFiles.createFolder("dsf",u);
	    Email e = new Email();
	    e.setId(0);
        Email e1 = new Email();
        e1.setId(1);
        Email e2 = new Email();
        e2.setId(2);
        Email e3 = new Email();
        e3.setId(3);
        Email e4 = new Email();
        e4.setId(4);
        Email e5 = new Email();
        e5.setId(5);

        ArrayList<Email> inboxList = u.getDefaultFolders().get(0).getEmailsList();
		ArrayList<Email> priorityList = u.getDefaultFolders().get(1).getEmailsList();
		ArrayList<Email> draftList = u.getDefaultFolders().get(3).getEmailsList();
		ArrayList<Email> trashList = u.getDefaultFolders().get(2).getEmailsList();
		ArrayList<Email> sentList = u.getDefaultFolders().get(4).getEmailsList();

		ArrayList<Email> userList = u.getUserFolders().get(0).getEmailsList();

        //System.out.println(inboxList);
		//System.out.println(userList);


	/*	inboxList.add(e);
		inboxList.add(e1);
		inboxList.add(e2);
		inboxList.add(e3);
		inboxList.add(e4);
		inboxList.add(e5);*/
/*
		System.out.println(inboxList.size() + " " + inboxList);
		System.out.println(userList.size() + " " + userList);
		System.out.println(trashList.size() + " " + trashList);

		/*inboxList.clear();
		userList.clear();*/
		ArrayList<Integer> ids = new ArrayList<>();

		ids.add(0);
		ids.add(1);
		ids.add(2);
		ids.add(3);
		ids.add(4);
		ids.add(5);


		UserFacade uf = new UserFacade(u);
/*
		uf.bulkMove(ids, 0, 0);

		System.out.println(inboxList.size() + " " + inboxList);
		System.out.println(userList.size() + " " + userList);
*/

		/*uf.bulkDelete(ids, 0);


		System.out.println(inboxList.size() + " " + inboxList);
		System.out.println(trashList.size() + " " + trashList);
		System.out.println(userList.size() + " " + userList);
*/

		//uf.bulkRetriveFromTrash(ids);
/*
		System.out.println(inboxList.size() + " " + inboxList);
		System.out.println(trashList.size() + " " + trashList);
		System.out.println(userList.size() + " " + userList);
		System.out.println(priorityList.size() + " " + priorityList);
		System.out.println(draftList.size() + " " + draftList);
		System.out.println(sentList.size() + " " + sentList);
*/


		//uf.addToPriorityInbox(4);
		draftList.add(e3);
		System.out.println(inboxList.size() + " " + inboxList);
		//System.out.println(trashList.size() + " " + trashList);
		//System.out.println(userList.size() + " " + userList);
		//System.out.println(priorityList.size() + " " + priorityList);
		System.out.println(draftList.size() + " " + draftList);
		System.out.println(sentList.size() + " " + sentList);


		e.addReciever(u2.getEmailAddress());

		uf.fromDraftResendEmail(e, 3, true);

		System.out.println(inboxList.size() + " " + inboxList);
		//System.out.println(trashList.size() + " " + trashList);
		//System.out.println(userList.size() + " " + userList);
		//System.out.println(priorityList.size() + " " + priorityList);
		System.out.println(draftList.size() + " " + draftList);
		System.out.println(sentList.size() + " " + sentList);


	}


}
